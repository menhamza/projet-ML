#test file
def f(x):
    return 2*x

print(f(3))